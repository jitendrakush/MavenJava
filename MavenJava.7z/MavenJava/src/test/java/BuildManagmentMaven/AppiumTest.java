package BuildManagmentMaven;

import org.junit.Test;

public class AppiumTest {
	
	@Test
	public void NativeAndroidApp() {
		System.out.println("NativeAndroidApp");
	}
	
	@Test
	public void IosApp() {
		System.out.println("IosApp");
	}

}
