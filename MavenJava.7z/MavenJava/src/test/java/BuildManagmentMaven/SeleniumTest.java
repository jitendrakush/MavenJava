package BuildManagmentMaven;

import org.junit.Test;

public class SeleniumTest {

	
//testng xml from maven	
//how to execute all test cases from test folder- mvn test	
	@Test
	public void BrowserAutomation() {
		System.out.println("BrowserAutomation");
	}
	@Test
	public void elementsUi() {
		System.out.println("elementsUi");
	}
}
