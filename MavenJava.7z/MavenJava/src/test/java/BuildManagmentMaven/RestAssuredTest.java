package BuildManagmentMaven;

import org.junit.Test;

public class RestAssuredTest {
	
	@Test
	public void postJira() {
		System.out.println("postJira");
	}
	@Test
	public void deleteTwitter() {
		System.out.println("deleteTwitter");
	}
}
